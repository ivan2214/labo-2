Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.

consigna:

Una web que teenga una seccion con un formulario centrado al medio, donde tendra un input para ingresar un numero y abajo 3 opciones que seran invertir el numero, contar los impares y contar los primos.
Abajo un boton para enviar el formulario centrado que diga procesar.
Solo dame el contenido dentro del main

<main class="flex justify-center h-full items-center">
  
</main>

