Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.

consigna:

Una web que contenga un formulario con un titulo que diga Financiera, un input para ingresar un deposito inicial, unos switchs para los plazos que son 30 dias, 45 dias, 60 dias y 90 dias.
Un boton en el meedio que diga simular.
Dame solo el codigo para lo que estaria dentro de main 

<main class="flex justify-center h-full items-center">
  
</main>


prompt2 para el ganancias.php

Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.

consigna:

Una web que contenga una tabla con lo siguiente:
Deposito, plazo, interes generado y monto total

Dame solo el codigo para lo que estaria dentro de main


<main class="flex justify-center h-full items-center">
  
</main>