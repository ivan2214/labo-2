Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.

consigna:

Una web que contenga un formulario de inicio de sesion, que contenga un input de email y un input de password, que contenga un boton iniciar sesion.
Solo dame el conteenido que va dentro deel main que te proporciono.

<main class="flex justify-center h-full items-center">
  
</main>



prompt2

Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.

consigna:
Una web que muestre el email del usuario y la contraseña ingresada.
Solo dame el conteenido que va dentro deel main que te proporciono.


<main class="flex justify-center h-full items-center">
  
</main>

