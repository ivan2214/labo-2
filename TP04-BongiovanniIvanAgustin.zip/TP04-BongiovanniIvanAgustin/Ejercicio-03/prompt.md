Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.

consigna:

Una web que contenga un titulo quee diga registro enfermeria pegado a la izquierda de la pantalla , una linea divisora entre el titulo y un formulario que ocupa todo el ancho, en el formulariolos datos que tendra son:
- Horas trabajadas de tipo numero
- Un select para seleccionar un turno 
- Una lista de dias de la semana dee lunes a domingo con un checkbox para cada dia
Al final de todos los campos debe ir un boton que diga calccular centrado al medio.
Solo dame lo que va dentro del main

<main class="flex justify-center h-full items-center">
  
</main>


prompt2 para el proccesa.php

Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.

consigna:

Una web que contenga una seccion que diga horas trabajadas y un numero, abajo turno y un turno, luego abajo de esa seccion una tabla con lo siguiente:
-En el thead dia y honorario
-En el tbody los dias y sus honorarios
-El total de honorarios de todos los dias
Esta tabla debe cumplir con todo los estandares de w3c, ser lo mas semanticos posible y tambien lo mas accesible para los usuarios.

<main class="flex justify-center h-full items-center">
  
</main>