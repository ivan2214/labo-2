
<footer class="container bg-dark text-white d-flex align-items-center justify-content-center">
    <section class="row">
        <p class="col-12 pt-4">Copyright 2024 - Cátedra Laboratorio II</p>
    </section>
</footer>
</body>
</html>