<?php
$juegos = 
[   
    'Age Of Mythology Retold' => 22.99,
    'NBA 2K25' => 69.99,
    'Baldurs Gate III' => 27.99,
    'Fallout 76' => 23.99,
    'CoD Black Ops 6' => 69.99
];
?>


