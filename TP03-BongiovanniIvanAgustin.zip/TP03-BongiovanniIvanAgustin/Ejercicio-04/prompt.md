Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.



consigna:  

Crea una interfaz de usuario web que contenga un contenedor principal que ocupe toda la pantalla, con un aside a la izquierda que muestre "Juegos Disponibles" y una lista vertical de juegos, cada uno con su imagen, nombre y precio. A la derecha, incluye una sección central con el título "Resultados del Hot Sale", donde se presente una tabla con los resultados de ventas, incluyendo columnas para el nombre del juego, la cantidad vendida y el monto recaudado, además de un área destacada que muestre el monto total recaudado abajo de la tabla.