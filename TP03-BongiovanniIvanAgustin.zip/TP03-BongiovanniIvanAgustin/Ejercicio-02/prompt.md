Actua como un experto en desarrollo web, en php, css, tailwindcss y html5, sigue los estandares de w3c, quiero que seas lo mas semantico posible, utilices tailwindcss y no uses divs.



consigna:  

crear 2 secciones dentro del main, una que teenga mi carton que son (números distribuidos en 5 filas y 2 columnas – utilice bucles)
y la otra que muestre el carton ganador con la cantidad de aciertos


Solo dame la parte del medio osea lo que iria dentro del body, por ahora este es mi index.php.

<main class="flex justify-center h-full items-center">



</main>

